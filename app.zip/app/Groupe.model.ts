export interface Groupe {

    name : string,
    style : string,
    members : number
    
}